#include "udpserver.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    UdpServer W;
    W.show();
    
    return a.exec();
}
